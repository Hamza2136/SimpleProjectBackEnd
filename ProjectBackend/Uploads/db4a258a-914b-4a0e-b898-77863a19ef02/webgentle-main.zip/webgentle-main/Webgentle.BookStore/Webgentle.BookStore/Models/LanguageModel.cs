﻿namespace Webgentle.BookStore.Models
{
    public class LanguageModel
    {
        public int id { get; set; }
        public string text { get; set; }
    }
}
